// ═══════════════════════════════════════════════════════════════════════════
// AUTH CONTEXT - Authentication state management
// ═══════════════════════════════════════════════════════════════════════════
//
// Ye file React Context API use karti hai taake login/logout functionality
// aur user info SAARE components mein available ho.
//
// Bina context ke, har component ko props pass karne padte hain. Context se
// hum globally state share kar sakte hain.
//
// Ye file kya provide karti hai:
//   1. user — current logged-in user ki info
//   2. login() — login karne ka function
//   3. logout() — logout karne ka function
//   4. loading — initial check ho raha hai ya nahi
//
// JWT (JSON Web Token) kya hai?
//   - Server password check karke ek special "token" deta hai
//   - Hum is token ko localStorage mein save karte hain
//   - Har API request mein ye token bhejte hain (proof k hum logged in hain)
//   - Token 7 din ke baad expire ho jata hai
// ═══════════════════════════════════════════════════════════════════════════

import React, { createContext, useState, useContext, useEffect } from 'react';
import axios from 'axios';

// Step 1: Context create karo
const AuthContext = createContext();

// Step 2: API base URL
// Pehle .env file se lo, agar nahi mile to default localhost use karo
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// ─── PROVIDER COMPONENT ─────────────────────────────────────────────────
// Ye component App.js mein wrap kiya gaya hai
// children = saari child components (saari pages)
export const AuthProvider = ({ children }) => {
  // ─── STATE ─────────────────────────────────────────────────────────────
  const [user, setUser] = useState(null);          // Logged-in user
  const [loading, setLoading] = useState(true);    // Initial load check

  // ─── INITIAL LOAD CHECK ────────────────────────────────────────────────
  // App start hote hi check karo: localStorage mein token hai ya nahi?
  // Agar hai to user ko already logged-in maan lo (page refresh mein logout na ho)
  useEffect(() => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');

    if (token && userData) {
      try {
        // localStorage mein user data JSON string mein hota hai
        // Use parse karke object banao
        setUser(JSON.parse(userData));

        // Default headers mein Authorization token add karo
        // Phir har API request mein automatically jayega
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      } catch (e) {
        // Agar localStorage corrupt hai to clear kar do
        localStorage.removeItem('token');
        localStorage.removeItem('user');
      }
    }
    setLoading(false);    // Loading complete
  }, []);    // [] = sirf ek baar chalo (mount pe)

  // ─── LOGIN FUNCTION ────────────────────────────────────────────────────
  // Email aur password leke backend ko bhejta hai
  const login = async (email, password) => {
    // Step 1: Backend ko login request bhejo
    const res = await axios.post(`${API_URL}/auth/login`, { email, password });

    // Step 2: Token aur user data localStorage mein save karo
    localStorage.setItem('token', res.data.token);
    localStorage.setItem('user', JSON.stringify(res.data));

    // Step 3: Future requests ke liye Authorization header set karo
    axios.defaults.headers.common['Authorization'] = `Bearer ${res.data.token}`;

    // Step 4: State mein user save karo
    setUser(res.data);

    // Step 5: User object wapas bhejo (LoginPage redirect ke liye use karega)
    return res.data;
  };

  // ─── LOGOUT FUNCTION ───────────────────────────────────────────────────
  const logout = () => {
    // localStorage clear karo
    localStorage.removeItem('token');
    localStorage.removeItem('user');

    // Default headers se Authorization hatao
    delete axios.defaults.headers.common['Authorization'];

    // State mein user null kar do
    setUser(null);
  };

  // ─── CONTEXT VALUES PROVIDE KARO ───────────────────────────────────────
  // Ye saari values har child component ko available hongi useAuth() se
  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

// ─── CUSTOM HOOK ─────────────────────────────────────────────────────────
// Components yahaan se context access karte hain
// Misaal: const { user, login } = useAuth();
export const useAuth = () => useContext(AuthContext);
