const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { uploadResource, searchResources, downloadResource, getMyResources, deleteResource } = require('../controllers/resourceController');

router.get('/search', protect, searchResources);
router.get('/my', protect, authorize('instructor', 'admin'), getMyResources);
router.get('/:id/download', protect, downloadResource);
// FIX: pass type as query param so multer destination can read it reliably
router.post('/upload', protect, authorize('instructor', 'admin'), upload.single('file'), uploadResource);
router.delete('/:id', protect, authorize('instructor', 'admin'), deleteResource);

module.exports = router;
