const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Ensure upload folders exist
['uploads', 'uploads/materials', 'uploads/past_papers'].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    // FIX: req.body.type is unreliable with multipart - use query param or default
    // The type comes from FormData field - multer parses fields in order received
    // We store everything in materials by default, rename folder after if needed
    // REAL FIX: always use uploads/temp and move, OR use query param
    const type = req.query.type || req.body.type || 'course_material';
    const folder = type === 'past_paper' ? 'uploads/past_papers' : 'uploads/materials';
    if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
    cb(null, folder);
  },
  filename: function(req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const fileFilter = (req, file, cb) => {
  const allowedTypes = /pdf|jpg|jpeg|png/;
  const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = allowedTypes.test(file.mimetype);
  if (extname && mimetype) return cb(null, true);
  cb(new Error('Only PDF, JPG, PNG files are allowed'));
};

const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter
});

module.exports = upload;
