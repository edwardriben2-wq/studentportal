// ═══════════════════════════════════════════════════════════════════════════
// SERVER.JS - Online Examination System ka main backend file
// ═══════════════════════════════════════════════════════════════════════════
//
// Ye file Express server start karti hai.
// Express ek Node.js ka framework hai jo HTTP requests ko handle karta hai.
//
// Saadi misaal: Jab student browser mein login button dabata hai,
//              browser ek request bhejta hai → ye file usko receive karti hai
//              → uske baad sahi controller ko bhejti hai → wo database check
//              karta hai → response wapas browser mein chala jata hai.
// ═══════════════════════════════════════════════════════════════════════════

// Step 1: Required packages import karte hain
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs');
const helmet = require('helmet');

// Step 2: .env file ki values load karo (PORT, MONGO_URI, JWT_SECRET, etc.)
dotenv.config();

// ───────────────────────────────────────────────────────────────────────────
// Step 3: Upload folders auto-create karo (agar nahi hain to)
// ───────────────────────────────────────────────────────────────────────────
const uploadFolders = ['uploads', 'uploads/materials', 'uploads/past_papers'];
uploadFolders.forEach(folder => {
  if (!fs.existsSync(folder)) {
    fs.mkdirSync(folder, { recursive: true });
    console.log(`📁 Created folder: ${folder}`);
  }
});

// Step 4: Express app create karo
const app = express();

// ───────────────────────────────────────────────────────────────────────────
// Step 5: Middleware setup
// ───────────────────────────────────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors({ origin: '*', credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ───────────────────────────────────────────────────────────────────────────
// Step 6: API Routes
// ───────────────────────────────────────────────────────────────────────────
app.use('/api/auth',       require('./routes/authRoutes'));
app.use('/api/admin',      require('./routes/adminRoutes'));
app.use('/api/instructor', require('./routes/instructorRoutes'));
app.use('/api/student',    require('./routes/studentRoutes'));
app.use('/api/exam',       require('./routes/examRoutes'));
app.use('/api/resources',  require('./routes/resourceRoutes'));

// Health check route
app.get('/api/health', (req, res) => {
  res.json({
    status: 'API is running ✅',
    time: new Date().toLocaleString('en-PK', { timeZone: 'Asia/Karachi' })
  });
});

// ───────────────────────────────────────────────────────────────────────────
// Step 7: Error handler
// ───────────────────────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('❌ Server error:', err.message);
  const isProduction = process.env.NODE_ENV === 'production';
  res.status(err.status || 500).json({
    message: isProduction ? 'Internal server error' : err.message
  });
});

// ───────────────────────────────────────────────────────────────────────────
// Step 8: Auto-fix database indexes on startup
// Ye function purane galat indexes ko hata kar naye sahi indexes banata hai
// Server start hote hi automatically chal jata hai - koi alag script nahi
// ───────────────────────────────────────────────────────────────────────────
async function autoFixIndexes() {
  try {
    const db = mongoose.connection.db;

    // Users collection - studentId sparse index
    try {
      const userIndexes = await db.collection('users').indexes();
      const oldStudentIdIdx = userIndexes.find(i => i.name === 'studentId_1' && !i.sparse);
      if (oldStudentIdIdx) {
        await db.collection('users').dropIndex('studentId_1');
        console.log('✅ Fixed: Old studentId index removed');
      }
    } catch (e) { /* ignore */ }

    try {
      await db.collection('users').createIndex(
        { studentId: 1 },
        { unique: true, sparse: true, name: 'studentId_sparse' }
      );
    } catch (e) { /* already exists */ }

    // Attempts collection - non-unique index
    try {
      const attemptIndexes = await db.collection('attempts').indexes();
      const oldUniqueIdx = attemptIndexes.find(i => i.name === 'exam_1_student_1' && i.unique);
      if (oldUniqueIdx) {
        await db.collection('attempts').dropIndex('exam_1_student_1');
        console.log('✅ Fixed: Old unique attempts index removed');
      }
    } catch (e) { /* ignore */ }

    // Clean orphan attempts
    try {
      const Attempt = require('./models/Attempt');
      const allAttempts = await Attempt.find().populate('exam').populate('student');
      const orphans = allAttempts.filter(a => !a.exam || !a.student);
      if (orphans.length > 0) {
        const ids = orphans.map(a => a._id);
        await Attempt.deleteMany({ _id: { $in: ids } });
        console.log(`✅ Cleaned ${orphans.length} orphan attempts`);
      }
    } catch (e) { /* ignore */ }
  } catch (err) {
    console.log('⚠️  Index check skipped:', err.message);
  }
}

// ───────────────────────────────────────────────────────────────────────────
// Step 9: MongoDB se connect karo, phir server start karo
// ───────────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;

mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    console.log('✅ MongoDB connected successfully');

    // Auto-fix indexes on startup
    await autoFixIndexes();

    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`   Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`   Test URL: http://localhost:${PORT}/api/health`);
    });
  })
  .catch(err => {
    console.error('❌ MongoDB connection failed:', err.message);
    console.error('   Check: Is MongoDB running? Is MONGO_URI correct in .env?');
    process.exit(1);
  });
