const Resource = require('../models/Resource');
const Course = require('../models/Course');
const path = require('path');
const fs = require('fs');

const uploadResource = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: 'No file uploaded' });
    const { title, description, type, courseId, year, semester: paperSemester } = req.body;
    const course = await Course.findById(courseId);
    if (!course) return res.status(404).json({ message: 'Course not found' });

    // FIX: Normalize path separators - store with forward slashes for cross-platform
    const normalizedPath = req.file.path.replace(/\\/g, '/');

    const resource = await Resource.create({
      title,
      description,
      type,
      course: courseId,
      courseCode: course.courseCode,
      courseName: course.courseName,
      uploadedBy: req.user._id,
      fileName: req.file.originalname,
      filePath: normalizedPath,
      fileType: path.extname(req.file.originalname).replace('.', ''),
      fileSize: req.file.size,
      year: year ? parseInt(year) : null,
      semester: paperSemester
    });
    res.status(201).json(resource);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const searchResources = async (req, res) => {
  try {
    const { query, type } = req.query;
    const filter = { isActive: true };
    if (type) filter.type = type;
    if (query) {
      filter.$or = [
        { courseCode: { $regex: query, $options: 'i' } },
        { courseName: { $regex: query, $options: 'i' } },
        { title: { $regex: query, $options: 'i' } }
      ];
    }
    const resources = await Resource.find(filter)
      .populate('uploadedBy', 'name')
      .sort({ createdAt: -1 });
    res.json(resources);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// FIX: Robust download with multiple path fallbacks for Windows + Linux
const downloadResource = async (req, res) => {
  try {
    const resource = await Resource.findById(req.params.id);
    if (!resource) return res.status(404).json({ message: 'Resource not found' });

    // Try multiple path variations to find the file
    const backendDir = path.join(__dirname, '..');
    const possiblePaths = [
      // Stored relative path (most common)
      path.resolve(backendDir, resource.filePath),
      // If filePath is already absolute
      resource.filePath,
      // With backend prefix removed if duplicate
      path.resolve(backendDir, resource.filePath.replace(/^backend[\/\\]/, '')),
      // Just the filename in uploads folder
      path.resolve(backendDir, 'uploads', path.basename(resource.filePath)),
      // In uploads/materials
      path.resolve(backendDir, 'uploads', 'materials', path.basename(resource.filePath)),
      // In uploads/past_papers
      path.resolve(backendDir, 'uploads', 'past_papers', path.basename(resource.filePath))
    ];

    let foundPath = null;
    for (const p of possiblePaths) {
      if (fs.existsSync(p)) {
        foundPath = p;
        break;
      }
    }

    if (!foundPath) {
      console.error('File not found. Tried paths:', possiblePaths);
      return res.status(404).json({ message: 'File not found on server. Please re-upload.' });
    }

    // Only increment counter if file was found
    resource.downloadCount += 1;
    await resource.save();

    res.download(foundPath, resource.fileName, (err) => {
      if (err && !res.headersSent) {
        console.error('Download error:', err);
        res.status(500).json({ message: 'Download failed' });
      }
    });
  } catch (err) {
    if (!res.headersSent) res.status(500).json({ message: err.message });
  }
};

const getMyResources = async (req, res) => {
  try {
    const resources = await Resource.find({ uploadedBy: req.user._id }).sort({ createdAt: -1 });
    res.json(resources);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const deleteResource = async (req, res) => {
  try {
    const resource = await Resource.findById(req.params.id);
    if (!resource) return res.status(404).json({ message: 'Resource not found' });
    if (resource.uploadedBy.toString() !== req.user._id.toString() && req.user.role !== 'admin')
      return res.status(403).json({ message: 'Not authorized' });

    // Try multiple paths for deletion too
    const backendDir = path.join(__dirname, '..');
    const possiblePaths = [
      path.resolve(backendDir, resource.filePath),
      resource.filePath,
      path.resolve(backendDir, 'uploads', path.basename(resource.filePath))
    ];
    for (const p of possiblePaths) {
      if (fs.existsSync(p)) {
        try { fs.unlinkSync(p); } catch (e) { /* ignore */ }
        break;
      }
    }

    await Resource.findByIdAndDelete(req.params.id);
    res.json({ message: 'Resource deleted' });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

module.exports = { uploadResource, searchResources, downloadResource, getMyResources, deleteResource };
