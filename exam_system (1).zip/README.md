# 🎓 Online Examination & Quiz Management System

**Final Year Project | Maher Hamza | BScs Sem VIII | University of Education Lahore**

---

## 📋 ABOUT THIS PROJECT

Ye **MERN stack** (MongoDB, Express, React, Node) pe bana online exam system hai. 3 roles support karta hai:

- **Admin** — sab kuch manage karta hai
- **Instructor** — exam banata, grade karta
- **Student** — exam deta hai

### ✨ Khaas Features

- ✅ MCQ + Short Answer questions
- ✅ Auto-grading for MCQ
- ✅ Cheating detection (5 types)
- ✅ Timer with auto-submit
- ✅ Past papers + course materials library
- ✅ Performance charts & analytics
- ✅ Admin **Database Cleanup** button
- ✅ **NO rate limit** — unlimited login attempts
- ✅ Auto-create upload folders on server start

---

# 🚀 PART 1: LOCAL SETUP (Apne computer pe chalana)

### ⏱️ Time: 30-45 minutes (pehli baar)

## 1️⃣ Required Software Install Karo

### A. Node.js (Latest LTS)
1. Browser: **https://nodejs.org**
2. Green "LTS" button dabao → download
3. `.msi` file pe double click
4. **"Next" → "Next" → "Install"** (default settings)
5. **Test:** CMD kholo → `node --version` → `v20.x.x` aana chahiye

### B. MongoDB Community
1. Browser: **https://www.mongodb.com/try/download/community**
2. Settings:
   - Version: **Latest 7.0+**
   - Platform: **Windows**
   - Package: **msi**
3. Download → install
4. **CRITICAL:** Installer mein "Install MongoDB as a Service" ka checkbox **ON** rakho
5. **MongoDB Compass** bhi install karo (visual database tool)
6. **Test:** CMD → `mongod --version`

### C. VS Code
1. **https://code.visualstudio.com**
2. Download → install
3. **"Add to PATH"** checkbox **ON** karo

---

## 2️⃣ Project Setup

### Step 1: Project extract karo

1. **Desktop** pe ek folder banao: `exam-project`
2. **`exam_system_FINAL.zip`** ko uss folder mein extract karo
3. Final structure:
   ```
   Desktop\exam-project\exam_system\
   ├── backend\
   ├── frontend\
   ├── documentation\
   └── README.md
   ```

### Step 2: VS Code mein kholo

1. VS Code start karo
2. **File → Open Folder** → `exam_system` select karo
3. **"Yes, I trust the authors"** dabao

### Step 3: Terminal kholo (CMD)

1. **Terminal → New Terminal**
2. Top right pe `∨` arrow click → **"Select Default Profile"** → **Command Prompt**
3. Old terminal close karo (X dabake)
4. **Terminal → New Terminal** dobara

---

## 3️⃣ Backend Setup

### Terminal mein:

```cmd
cd backend
```

### `.env` file already pre-configured hai

Open `backend/.env` mein dekho:
```
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/exam_system
JWT_SECRET=mySecretKeyForExamSystemFYPMaherHamza2026
JWT_EXPIRE=7d
NODE_ENV=development
```

Ye sahi values hain. Save karo (Ctrl+S).

### Dependencies install karo:

```cmd
npm install
```

⏳ 2-5 min lagega

### MongoDB chal raha hai check karo:

**Naya terminal kholo:**
```cmd
sc query MongoDB
```

- `STATE: 4 RUNNING` = ✅ chal raha hai
- `STATE: 1 STOPPED` = chalu karo:
  ```cmd
  net start MongoDB
  ```

> Agar "Access denied" aaye to: VS Code band karo → desktop pe right click VS Code icon → **"Run as administrator"**

### Database seed karo (default users):

**Pehle terminal mein wapas jao** (jo backend folder mein hai):
```cmd
node seed.js
```

Output dikhega:
```
✅ MongoDB connected
✅ 8 students created
╔══════════════════════════════════════════════════════╗
║           DATABASE SEEDED SUCCESSFULLY!              ║
║  ADMIN: admin@exam.com / admin123                   ║
╚══════════════════════════════════════════════════════╝
```

### Server start karo:

```cmd
npm run dev
```

Output:
```
📁 Folder banaya: uploads
✅ MongoDB se connection successful
🚀 Server chal raha hai port 5000 pe
```

🎉 **Backend ready!** Iss terminal ko **band mat karo**.

---

## 4️⃣ Frontend Setup

### NAYA terminal kholo (Terminal → New Terminal)

```cmd
cd frontend
npm install
```

⏳ 3-7 min

### Frontend start karo:

```cmd
npm start
```

Output:
```
Compiled successfully!
Local: http://localhost:3000
```

Browser apne aap khulega login screen pe.

🎉 **Project chal raha hai!**

---

## 5️⃣ Login Credentials

### 🔑 Admin
```
Email:    admin@exam.com
Password: admin123
```

### 👨‍🏫 Instructor
```
Email:    ali.instructor@exam.com
Password: instructor123
```

### 🎓 Student (Sem 8)
```
Email:    maher.student@exam.com
Password: student123
```

### 📚 Total 8 students (one per semester):
- ahmed.student@exam.com (Sem 1)
- fatima.student@exam.com (Sem 2)
- usman.student@exam.com (Sem 3)
- ayesha.student@exam.com (Sem 4)
- hassan.student@exam.com (Sem 5)
- zainab.student@exam.com (Sem 6)
- bilal.student@exam.com (Sem 7)
- maher.student@exam.com (Sem 8)

(Sab ka password: `student123`)

---

# 🌐 PART 2: LIVE DEPLOYMENT (Internet pe daalna)

Project ko free mein internet pe daalne ke 3 free services use karenge:

| Service | Use | URL |
|---------|------|-----|
| MongoDB Atlas | Cloud database | https://www.mongodb.com/atlas |
| Render | Backend hosting | https://render.com |
| Vercel | Frontend hosting | https://vercel.com |

### ⏱️ Time: 60-90 minutes (pehli baar)

---

## STEP 1: GitHub pe code daalo

### A. GitHub account banao
1. **https://github.com** → Sign up
2. Email verify karo

### B. Repository banao
1. Top-right **"+" → "New repository"**
2. Name: `online-exam-system`
3. Public select karo
4. **"Create repository"**

### C. Local project ko GitHub se connect karo

**VS Code terminal mein** (project root pe):

```cmd
cd ..
git init
git add .
git commit -m "Initial commit - Final Year Project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/online-exam-system.git
git push -u origin main
```

> `YOUR_USERNAME` ko apne GitHub username se replace karo

---

## STEP 2: MongoDB Atlas Setup (Cloud Database)

### A. Account banao
1. **https://www.mongodb.com/atlas** → "Try Free"
2. Sign up

### B. Free Cluster banao
1. **"Build a Database"** dabao
2. **FREE M0** select karo
3. Provider: **AWS**, Region: **closest to Pakistan**
4. Cluster name: `exam-cluster`
5. **"Create"**

### C. Database User banao
1. Username: `examadmin`
2. Password: koi strong password (note kar lo!)
3. **"Create User"**

### D. Network Access (IP whitelist)
1. **"Network Access"** menu
2. **"Add IP Address"**
3. **"Allow Access from Anywhere"** (0.0.0.0/0)
4. **"Confirm"**

### E. Connection String lo
1. **"Database"** → **"Connect"**
2. **"Drivers"** select karo
3. Connection string copy karo:
   ```
   mongodb+srv://examadmin:<password>@exam-cluster.xxx.mongodb.net/?retryWrites=true&w=majority
   ```
4. `<password>` ko apne actual password se replace karo
5. End mein `/exam_system` add karo:
   ```
   mongodb+srv://examadmin:YOURPASS@exam-cluster.xxx.mongodb.net/exam_system?retryWrites=true&w=majority
   ```

### F. Cloud database seed karo

**VS Code terminal:**
```cmd
cd backend
```

Open `.env` aur temporarily MONGO_URI ko cloud wala lagao:
```
MONGO_URI=mongodb+srv://examadmin:YOURPASS@exam-cluster.xxx.mongodb.net/exam_system?retryWrites=true&w=majority
```

```cmd
node seed.js
```

Successfully ho gaya? Wapas localhost wala MONGO_URI lagao.

---

## STEP 3: Render pe Backend Deploy karo

### A. Account banao
1. **https://render.com** → **"Get Started"**
2. **"Continue with GitHub"** (easy hai)

### B. Web Service create karo
1. Dashboard → **"New +" → "Web Service"**
2. **"Build and deploy from a Git repository"** → **"Next"**
3. Apni `online-exam-system` repository connect karo

### C. Settings configure karo

| Field | Value |
|-------|-------|
| **Name** | `exam-backend` |
| **Root Directory** | `backend` |
| **Build Command** | `npm install` |
| **Start Command** | `node server.js` |
| **Plan** | **Free** |

### D. Environment Variables add karo

Scroll down → **"Advanced"** → **"Add Environment Variable"** 5 baar:

| Key | Value |
|-----|-------|
| `MONGO_URI` | (Atlas connection string from Step 2.E) |
| `JWT_SECRET` | `myProductionSecretKey123!XYZ` |
| `JWT_EXPIRE` | `7d` |
| `NODE_ENV` | `production` |
| `PORT` | `5000` |

### E. Deploy karo
1. **"Create Web Service"** dabao
2. ⏳ 5-10 min wait (build hoga)
3. Top mein URL dikhega: `https://exam-backend-xxxx.onrender.com`
4. **NOTE THIS URL!**

### F. Test karo
Browser mein: `https://exam-backend-xxxx.onrender.com/api/health`

Output:
```json
{"status":"API zinda hai ✅","time":"..."}
```

✅ Backend live!

---

## STEP 4: Vercel pe Frontend Deploy karo

### A. Account banao
1. **https://vercel.com** → **"Sign Up"**
2. **"Continue with GitHub"**

### B. Frontend ka environment variable update karo

**Pehle apni local frontend `.env` mein** Render backend ka URL daalo:

`frontend/.env`:
```
REACT_APP_API_URL=https://exam-backend-xxxx.onrender.com/api
```

(localhost ki jagah Render ka URL)

GitHub pe push karo:
```cmd
cd ..
git add .
git commit -m "Updated API URL for production"
git push
```

### C. Vercel pe import karo
1. Vercel dashboard → **"Add New" → "Project"**
2. Apni `online-exam-system` repo select karo
3. Settings:

| Field | Value |
|-------|-------|
| **Framework Preset** | Create React App |
| **Root Directory** | `frontend` |

### D. Environment Variable

**"Environment Variables"** section:

| Key | Value |
|-----|-------|
| `REACT_APP_API_URL` | `https://exam-backend-xxxx.onrender.com/api` |

### E. Deploy
1. **"Deploy"** dabao
2. ⏳ 1-2 min
3. URL milega: `https://online-exam-system-xxxx.vercel.app`

✅ **Project live ho gaya!**

---

## STEP 5: Live Testing

1. Vercel URL kholo browser mein
2. Login: `admin@exam.com` / `admin123`
3. Sab features test karo

---

## 🆘 Common Live Deployment Problems

### ❌ "CORS Error" — Vercel se Render ko request fail
**Solution:** Render ke `server.js` mein CORS already `origin: '*'` hai, so theek hona chahiye. Agar phir bhi error aaye:
- Render dashboard → Environment → `FRONTEND_URL = https://your-vercel.vercel.app`
- Redeploy

### ❌ Render service "sleeping" message
**Wajah:** Free tier 15 min idle ke baad sleep ho jata hai.
**Solution:** Pehli request 30s lagti hai (wake up ke liye). Wait karo.

### ❌ "Network Error" login pe
**Wajah:** Vercel ka `REACT_APP_API_URL` galat hai.
**Solution:** Vercel dashboard → Settings → Environment Variables → URL update karo → Redeploy.

### ❌ Login pe "Invalid credentials"
**Wajah:** Atlas mein seed nahi chala.
**Solution:** Step 2.F repeat karo (cloud database seed karo).

---

# 📋 PART 3: PROJECT KO ROZ ROZ CHALANA

Project band karne ke baad dobara chalane ke liye:

```cmd
# Terminal 1
cd backend
npm run dev

# Terminal 2
cd frontend
npm start
```

Browser khulega: http://localhost:3000

---

# 🆘 LOCAL PROBLEMS — SOLUTIONS

| Problem | Solution |
|---------|----------|
| `npm install` fail | `npm install --legacy-peer-deps` |
| MongoDB connection fail | `net start MongoDB` (Run as admin) |
| Port 5000 already in use | `taskkill /F /IM node.exe` |
| Login: Invalid credentials | `node seed.js` chalao |
| Compiled with errors | Project zip se dobara extract karo |
| File upload fail | Server restart karo (folders auto-create honge) |
| Old test data dikha raha | Admin login → "🧹 Clean Database" button dabao |

---

# 🎯 DEFAULT CREDENTIALS QUICK REFERENCE

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@exam.com | admin123 |
| Instructor | ali.instructor@exam.com | instructor123 |
| Instructor 2 | sara.instructor@exam.com | instructor123 |
| Student (Sem 1) | ahmed.student@exam.com | student123 |
| Student (Sem 2) | fatima.student@exam.com | student123 |
| Student (Sem 3) | usman.student@exam.com | student123 |
| Student (Sem 4) | ayesha.student@exam.com | student123 |
| Student (Sem 5) | hassan.student@exam.com | student123 |
| Student (Sem 6) | zainab.student@exam.com | student123 |
| Student (Sem 7) | bilal.student@exam.com | student123 |
| **Student (Sem 8)** | **maher.student@exam.com** | **student123** |

---

# 📚 PROJECT STRUCTURE

```
exam_system/
├── README.md                       ← YE FILE
├── backend/
│   ├── server.js                   ← Main server (Roman Urdu comments)
│   ├── .env                        ← Pre-configured
│   ├── package.json
│   ├── seed.js                     ← Default data creator
│   ├── controllers/                ← Business logic (commented)
│   │   ├── authController.js       ← Login logic
│   │   ├── adminController.js      ← Admin operations + cleanup
│   │   ├── instructorController.js
│   │   ├── studentController.js
│   │   ├── examController.js       ← Exam taking & cheating
│   │   └── resourceController.js
│   ├── models/                     ← Database schemas
│   │   ├── User.js
│   │   ├── Course.js
│   │   ├── Exam.js
│   │   ├── Attempt.js
│   │   └── Resource.js
│   ├── routes/                     ← API endpoints
│   ├── middleware/                 ← JWT auth + file upload
│   └── uploads/                    ← Auto-created on startup
│       ├── materials/
│       └── past_papers/
└── frontend/
    ├── .env
    ├── package.json
    └── src/
        ├── App.js
        ├── pages/
        │   ├── LoginPage.js
        │   ├── Admin/AdminDashboard.js   ← With Cleanup button
        │   ├── Instructor/InstructorDashboard.js
        │   ├── Student/StudentDashboard.js
        │   ├── Student/ExamPage.js       ← Most complex (commented)
        │   ├── Student/ResultsPage.js
        │   └── ResourcesPage.js
        ├── context/AuthContext.js        ← JWT state (commented)
        ├── utils/api.js                  ← Axios setup (commented)
        └── components/Common/Sidebar.js
```

---

# ✨ KYA NAYA HAI IS VERSION MEIN

✅ **Rate limit hata di** — unlimited login attempts
✅ **Upload folders auto-create** — server start hote hi
✅ **Database Cleanup button** — admin se ek click mein orphan data hatao
✅ **Deleted exam attempts ab nahi dikhayenge** — student aur admin dashboard pe
✅ **Roman Urdu comments** — backend & frontend mein har function explained
✅ **Live deployment guide** — step-by-step Render + Vercel + MongoDB Atlas

---

**Mubarak ho! 🎓 Defense ke liye All The Best!**
